import pandas as pd
import os
import yfinance as yf
from datetime import datetime, timedelta

DATA_FILE = "travel_expenses.csv"

def load_data():
    """
    Loads data from the CSV file. If file doesn't exist, returns an empty DataFrame.
    """
    if os.path.exists(DATA_FILE):
        df = pd.read_csv(DATA_FILE)
        # Ensure 'Date' column is datetime
        if 'Date' in df.columns:
            df['Date'] = pd.to_datetime(df['Date'])
        
        # Add missing columns if they don't exist (for migration)
        if 'Currency' not in df.columns:
            df['Currency'] = 'KRW'
        if 'Original Amount' not in df.columns:
            df['Original Amount'] = df['Amount']
        if 'Exchange Rate' not in df.columns:
            df['Exchange Rate'] = 1.0
            
        return df
    else:
        return pd.DataFrame(columns=["Date", "Category", "Item", "Amount", "Currency", "Original Amount", "Exchange Rate"])

def save_data(df):
    """
    Saves the DataFrame to a CSV file.
    """
    df.to_csv(DATA_FILE, index=False)

def calculate_metrics(df, total_budget):
    """
    Calculates total spent and remaining budget.
    Input df should have 'Amount' in base currency (KRW).
    """
    if df.empty:
        return 0, total_budget
    
    total_spent = df["Amount"].sum()
    remaining = total_budget - total_spent
    return total_spent, remaining

def get_exchange_rate(currency_code, target_date=None):
    """
    Get exchange rate for currency_code to KRW.
    If target_date is None, use today.
    """
    if currency_code == "KRW":
        return 1.0
    
    ticker_map = {
        "USD": "KRW=X",
        "EUR": "EURKRW=X",
        "JPY": "JPYKRW=X"
    }
    
    ticker = ticker_map.get(currency_code)
    if not ticker:
        return 1.0
        
    try:
        if target_date:
            # yfinance expects date string YYYY-MM-DD
            # We need end date as +1 day for download
            start_date = target_date.strftime("%Y-%m-%d")
            end_date = (target_date + timedelta(days=1)).strftime("%Y-%m-%d")
            data = yf.download(ticker, start=start_date, end=end_date, progress=False)
        else:
            data = yf.download(ticker, period="1d", progress=False)
            
        if not data.empty:
            # Use 'Close' price
            rate = data['Close'].iloc[-1].item()
            return rate
        else:
            # If no data (e.g., weekend), try fetching last 5 days
             data = yf.download(ticker, period="5d", progress=False)
             if not data.empty:
                 return data['Close'].iloc[-1].item()
             return 1.0
    except Exception as e:
        print(f"Error fetching rate: {e}")
        return 1.0
