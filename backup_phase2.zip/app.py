import streamlit as st
import pandas as pd
import plotly.express as px
from utils import load_data, save_data, calculate_metrics, get_exchange_rate
from datetime import datetime

# 페이지 설정
st.set_page_config(page_title="영현이의 여행 경비 관리도구", page_icon="✈️", layout="wide")

# CSS 스타일 적용
st.markdown("""
    <style>
    .metric-card {
        padding: 20px;
        border-radius: 10px;
        background-color: #f0f2f6;
        text-align: center;
        box-shadow: 2px 2px 5px rgba(0,0,0,0.1);
    }
    .stNumberInput input {
        font-weight: bold;
    }
    </style>
    """, unsafe_allow_html=True)

# 데이터 로드
if 'df_expenses' not in st.session_state:
    st.session_state.df_expenses = load_data()

# 세션 상태 초기화 (환율)
if 'exchange_rate' not in st.session_state:
    st.session_state.exchange_rate = 1.0

# 사이드바: 설정
st.sidebar.image("/Users/pudujibsa/Desktop/yeong/ai_study/personal.jpg", use_container_width=True)
st.sidebar.header("⚙️ 설정 (Settings)")
budget = st.sidebar.number_input("전체 예산 (Total Budget - KRW)", min_value=0, value=1000000, step=10000, format="%d")

if st.sidebar.button("데이터 초기화 (Reset Data)", type="primary"):
    st.session_state.df_expenses = pd.DataFrame(columns=["Date", "Category", "Item", "Amount", "Currency", "Original Amount", "Exchange Rate"])
    save_data(st.session_state.df_expenses)
    st.sidebar.success("데이터가 초기화되었습니다.")

st.sidebar.markdown("---")
st.sidebar.info("여행 경비를 효율적으로 관리하세요!\n\n제작: Antigravity AI")

# 메인 영역
st.title("✈️ 영현이의 여행 경비 관리도구")
st.markdown("### 실시간 경비 추적 및 분석 (다중 통화 지원)")

# 지표 계산
total_spent, remaining = calculate_metrics(st.session_state.df_expenses, budget)

# 주요 지표 표시
col1, col2, col3 = st.columns(3)
with col1:
    st.metric(label="💰 전체 예산 (Total Budget)", value=f"{budget:,.0f} KRW")

with col2:
    st.metric(label="💸 총 지출 (Total Spent)", value=f"{total_spent:,.0f} KRW", delta=f"{total_spent/budget*100:.1f}% 사용")

with col3:
    is_danger = remaining < (budget * 0.2)
    st.metric(label="💳 남은 잔액 (Remaining)", value=f"{remaining:,.0f} KRW", 
              delta=f"{remaining/budget*100:.1f}% 남음", delta_color="normal" if not is_danger else "inverse")

st.markdown("---")

# 레이아웃: 입력 폼 & 차트
row1_col1, row1_col2 = st.columns([1, 1])

def update_exchange_rate():
    # Helper to update rate based on current selection
    # Note: limitation of streamlit forms, better handled outside or via callback
    pass 

with row1_col1:
    st.subheader("📝 지출 내역 입력 (Add Expense)")
    
    # 환율 갱신을 위한 독립적인 컨트롤 (폼 외부 추천하지만 구조상 폼 내부가 깔끔)
    # 여기서는 폼 제출 시 환율을 확정하는 방식 사용
    # 또는 환율을 미리 조회하는 버튼 제공
    
    with st.container():
        col_date, col_curr = st.columns([1, 1])
        with col_date:
            date = st.date_input("날짜 (Date)", datetime.now())
        with col_curr:
            currency = st.selectbox("통화 (Currency)", ["KRW", "USD", "EUR", "JPY"])
            
    # 환율 자동 조회 (Session State 활용)
    # 날짜나 통화가 바뀌면 환율 업데이트 (Rerun 필요)
    # Streamlit 특성상 위 입력값 변경 시 전체 리런됨.
    # 따라서 여기서 바로 계산 가능.
    
    # Simple check to avoid fetch on every interaction if not needed, 
    # but for simplicity we fetch on currency change.
    current_rate = get_exchange_rate(currency, date)
    
    
    with st.form("expense_form", clear_on_submit=True):
        st.write(f"ℹ️ 적용 환율: 1 {currency} = {current_rate:.2f} KRW")
        
        category = st.selectbox("카테고리 (Category)", ["식비 (Food)", "교통 (Transport)", "숙박 (Accommodation)", "쇼핑 (Shopping)", "관광 (Activities)", "기타 (Others)"])
        item = st.text_input("상세 항목 (Item Description)")
        
        # 금액 입력 (현지 통화)
        amount_origin = st.number_input(f"금액 ({currency})", min_value=0.0, step=1.0 if currency=="JPY" else 0.01, format="%.2f")
        
        # 수동 환율 조정 (옵션)
        manual_rate = st.number_input("환율 조정 (Exchange Rate)", value=float(current_rate), min_value=0.0, step=0.1, format="%.2f")
        
        submit = st.form_submit_button("추가하기 (Add Expense)")
        
        if submit:
            final_krw = amount_origin * manual_rate
            new_data = pd.DataFrame({
                "Date": [pd.to_datetime(date)],
                "Category": [category],
                "Item": [item],
                "Amount": [final_krw], # KRW 환산 금액
                "Currency": [currency],
                "Original Amount": [amount_origin],
                "Exchange Rate": [manual_rate]
            })
            st.session_state.df_expenses = pd.concat([st.session_state.df_expenses, new_data], ignore_index=True)
            save_data(st.session_state.df_expenses)
            st.success(f"✅ 추가 완료: {item} ({amount_origin:,.2f} {currency} ≈ {final_krw:,.0f} KRW)")
            # st.rerun() # Form clear_on_submit handles input clear, rerun updates table

with row1_col2:
    st.subheader("📊 카테고리별 지출 (By Category)")
    if not st.session_state.df_expenses.empty:
        fig = px.pie(st.session_state.df_expenses, values='Amount', names='Category', hole=0.4)
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("데이터가 없습니다. 지출을 추가해주세요.")

# 하단: 상세 내역 및 일별 추이
st.markdown("---")
row2_col1, row2_col2 = st.columns([1, 1])

with row2_col1:
    st.subheader("📋 최근 지출 내역 (History)")
    if not st.session_state.df_expenses.empty:
        # 삭제 기능을 위한 선택 컬럼 추가 (화면 표시용)
        # st.data_editor를 사용하여 삭제 기능 구현
        # 사용자가 행을 선택하고 삭제 버튼을 누르는 방식
        
        display_df = st.session_state.df_expenses.copy()
        
        # 인덱스를 리셋하고 원본 인덱스를 보존 (삭제 시 식별용)
        display_df = display_df.reset_index()
        display_df = display_df.rename(columns={"index": "Original_Index"})

        display_df['Date'] = display_df['Date'].dt.date
        display_df = display_df.sort_values(by="Date", ascending=False)
        
        # 컬럼 순서 및 포맷 정리
        display_cols = ["Original_Index", "Date", "Category", "Item", "Original Amount", "Currency", "Amount", "Exchange Rate"]
        display_df = display_df[display_cols]
        
        # 표시용 컬럼명 (사용자 친화적)
        column_config = {
            "Original_Index": None, # 숨김
            "Date": "날짜",
            "Category": "카테고리",
            "Item": "항목",
            "Original Amount": st.column_config.NumberColumn("현지 금액", format="%.2f"),
            "Currency": "통화",
            "Amount": st.column_config.NumberColumn("원화 환산(KRW)", format="%d KRW"),
            "Exchange Rate": st.column_config.NumberColumn("적용 환율", format="%.2f")
        }

        st.info("🗑️ 지출 내역을 삭제하려면 아래 표에서 체크박스를 선택하고 '선택된 항목 삭제' 버튼을 누르세요.")
        
        # 선택 컬럼 추가
        display_df_with_selections = display_df.copy()
        display_df_with_selections.insert(0, "Select", False)

        # 데이터 에디터 표시
        edited_df = st.data_editor(
            display_df_with_selections,
            column_config={
                "Select": st.column_config.CheckboxColumn("선택", help="삭제할 항목을 선택하세요"),
                **column_config
            },
            hide_index=True,
            use_container_width=True,
            disabled=display_cols # 다른 컬럼은 수정 불가
        )
        
        # 삭제 버튼
        if st.button("🗑️ 선택된 항목 삭제 (Delete Selected)", type="secondary"):
            # 선택된 행의 Original_Index 가져오기
            selected_indices = edited_df[edited_df["Select"]]["Original_Index"].tolist()
            
            if selected_indices:
                # 원본 데이터프레임에서 해당 인덱스 삭제
                st.session_state.df_expenses = st.session_state.df_expenses.drop(selected_indices).reset_index(drop=True)
                save_data(st.session_state.df_expenses)
                st.success(f"✅ {len(selected_indices)}개의 항목이 삭제되었습니다.")
                st.rerun()
            else:
                st.warning("삭제할 항목을 선택해주세요.")
    else:
        st.text("지출 내역이 여기에 표시됩니다.")

with row2_col2:
    st.subheader("📈 일별 지출 추이 (Daily Trend)")
    if not st.session_state.df_expenses.empty:
        # 일별 지출 집계 (시간 제외, 날짜 기준)
        daily_df = st.session_state.df_expenses.copy()
        daily_df['Date'] = daily_df['Date'].dt.date
        daily_spend = daily_df.groupby('Date')['Amount'].sum().reset_index()
        
        # 막대 그래프 (Bar Chart)
        fig_line = px.bar(daily_spend, x='Date', y='Amount', title='Day by Day Spending (KRW)', text_auto='.2s')
        fig_line.update_layout(xaxis_title="날짜 (Date)", yaxis_title="지출 금액 (KRW)")
        st.plotly_chart(fig_line, use_container_width=True)
    else:
        st.text("일별 추이가 여기에 표시됩니다.")
