import streamlit as st
import pandas as pd
import plotly.express as px
from utils import load_data, save_data, calculate_metrics, get_exchange_rate, load_folders, save_folders
from datetime import datetime
import uuid

# 페이지 설정
st.set_page_config(page_title="영현이의 여행 경비 관리도구", page_icon="✈️", layout="wide")

# CSS 스타일 적용
st.markdown("""
    <style>
    .metric-card {
        padding: 20px;
        border-radius: 10px;
        background-color: #f0f2f6;
        text-align: center;
        box-shadow: 2px 2px 5px rgba(0,0,0,0.1);
    }
    .stNumberInput input {
        font-weight: bold;
    }
    </style>
    """, unsafe_allow_html=True)

# 초기화
if 'folders' not in st.session_state:
    st.session_state.folders = load_folders()

if 'current_trip_id' not in st.session_state:
    st.session_state.current_trip_id = None

if 'is_admin' not in st.session_state:
    st.session_state.is_admin = False

if 'df_expenses' not in st.session_state:
    st.session_state.df_expenses = pd.DataFrame()

# 관리자 비밀번호
ADMIN_PASSWORD = "0713"

# --- 사이드바 ---
st.sidebar.image("/Users/pudujibsa/Desktop/yeong/ai_study/personal.jpg", use_container_width=True)
st.sidebar.header("⚙️ 설정 (Settings)")

if st.session_state.current_trip_id:
    current_trip = st.session_state.folders.get(st.session_state.current_trip_id)
    if current_trip:
        st.sidebar.success(f"현재 여행: {current_trip['name']}")
        if st.sidebar.button("🚪 여행 나가기 (Exit Trip)", type="primary"):
            st.session_state.current_trip_id = None
            st.session_state.df_expenses = pd.DataFrame()
            st.rerun()
    else:
        st.session_state.current_trip_id = None
        st.rerun()

st.sidebar.markdown("---")
st.sidebar.info("여행 경비를 효율적으로 관리하세요!\n\n제작: Antigravity AI")


# --- 메인 로직 ---

if st.session_state.current_trip_id is None:
    # 1. 랜딩 페이지 (로그인/참여)
    st.title("✈️ 영현이의 여행 경비 관리도구")
    st.markdown("### 여행을 선택하거나 관리자로 로그인하세요.")

    tab_guest, tab_admin = st.tabs(["👋 여행 참여하기 (Guest Join)", "🔐 관리자 모드 (Admin)"])

    with tab_guest:
        st.subheader("여행 참여하기")
        trip_options = {v['name']: k for k, v in st.session_state.folders.items()}
        
        if not trip_options:
            st.info("등록된 여행이 없습니다. 관리자에게 문의하세요.")
        else:
            selected_trip_name = st.selectbox("참여할 여행 선택", list(trip_options.keys()))
            password_input = st.text_input("여행 비밀번호 입력", type="password")
            
            if st.button("입장하기 (Enter)", type="primary"):
                trip_id = trip_options[selected_trip_name]
                trip_data = st.session_state.folders[trip_id]
                
                if password_input == trip_data['password']:
                    st.session_state.current_trip_id = trip_id
                    st.session_state.df_expenses = load_data(trip_id)
                    st.success(f"'{trip_data['name']}'에 입장합니다!")
                    st.rerun()
                else:
                    st.error("비밀번호가 올바르지 않습니다.")

    with tab_admin:
        st.subheader("관리자 로그인")
        
        if not st.session_state.is_admin:
            admin_pw = st.text_input("관리자 비밀번호", type="password", key="admin_pw_input")
            if st.button("로그인 (Login)"):
                if admin_pw == ADMIN_PASSWORD:
                    st.session_state.is_admin = True
                    st.success("관리자 로그인 성공!")
                    st.rerun()
                else:
                    st.error("관리자 비밀번호가 틀렸습니다.")
        else:
            st.success("관리자 권한으로 접속 중입니다.")
            if st.button("로그아웃 (Logout)"):
                st.session_state.is_admin = False
                st.rerun()
            
            st.markdown("---")
            st.subheader("➕ 새 여행 만들기")
            with st.form("create_trip_form"):
                new_trip_name = st.text_input("여행 이름 (예: 유럽 여행 2024)")
                new_trip_pw = st.text_input("접속 비밀번호 설정")
                new_trip_budget = st.number_input("총 예산 (KRW)", min_value=0, value=1000000, step=10000)
                
                if st.form_submit_button("여행 생성"):
                    if new_trip_name and new_trip_pw:
                        new_id = str(uuid.uuid4())
                        st.session_state.folders[new_id] = {
                            "name": new_trip_name,
                            "password": new_trip_pw,
                            "budget": int(new_trip_budget),
                            "created_at": datetime.now().strftime("%Y-%m-%d")
                        }
                        save_folders(st.session_state.folders)
                        st.success(f"'{new_trip_name}' 여행이 생성되었습니다.")
                        st.rerun()
                    else:
                        st.warning("이름과 비밀번호를 모두 입력해주세요.")
            
            st.markdown("---")
            st.subheader("🗑 여행 삭제")
            if st.session_state.folders:
                trip_to_delete = st.selectbox("삭제할 여행 선택", list(trip_options.keys()), key="delete_select")
                if st.button("선택한 여행 삭제"):
                    trip_id_to_del = trip_options[trip_to_delete]
                    del st.session_state.folders[trip_id_to_del]
                    save_folders(st.session_state.folders)
                    st.success(f"'{trip_to_delete}' 여행이 삭제되었습니다.")
                    st.rerun()
            else:
                st.info("삭제할 여행이 없습니다.")

else:
    # 2. 대시보드 모드 (Trip Selected)
    trip_id = st.session_state.current_trip_id
    trip_data = st.session_state.folders[trip_id]
    
    st.title(f"✈️ {trip_data['name']}")
    
    # 예산 관리 (관리자만 수정 가능, 게스트는 보기만)
    budget = trip_data['budget']
    
    if st.session_state.is_admin:
        with st.expander("💼 예산 수정 (관리자 전용)"):
            new_budget = st.number_input("전체 예산 수정 (KRW)", value=budget, key="budget_edit")
            if st.button("예산 업데이트"):
                trip_data['budget'] = int(new_budget)
                save_folders(st.session_state.folders)
                st.success("예산이 수정되었습니다.")
                st.rerun()
        budget = trip_data['budget'] # 갱신된 값 사용

    # 지표 계산
    total_spent, remaining = calculate_metrics(st.session_state.df_expenses, budget)

    # 주요 지표 표시
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric(label="💰 전체 예산 (Total Budget)", value=f"{budget:,.0f} KRW")
    with col2:
        st.metric(label="💸 총 지출 (Total Spent)", value=f"{total_spent:,.0f} KRW", delta=f"{total_spent/budget*100:.1f}% 사용" if budget > 0 else "0%")
    with col3:
        is_danger = remaining < (budget * 0.2)
        st.metric(label="💳 남은 잔액 (Remaining)", value=f"{remaining:,.0f} KRW", 
                  delta=f"{remaining/budget*100:.1f}% 남음" if budget > 0 else "0%", delta_color="normal" if not is_danger else "inverse")

    st.markdown("---")

    # 입력 폼 & 차트
    row1_col1, row1_col2 = st.columns([1, 1])

    with row1_col1:
        st.subheader("📝 지출 내역 입력 (Add Expense)")
        
        col_date, col_curr = st.columns([1, 1])
        with col_date:
            date = st.date_input("날짜 (Date)", datetime.now())
        with col_curr:
            currency = st.selectbox("통화 (Currency)", ["KRW", "USD", "EUR", "JPY"])
        
        current_rate = get_exchange_rate(currency, date)
        
        with st.form("expense_form", clear_on_submit=True):
            st.write(f"ℹ️ 적용 환율: 1 {currency} = {current_rate:.2f} KRW")
            
            category = st.selectbox("카테고리 (Category)", ["식비 (Food)", "교통 (Transport)", "숙박 (Accommodation)", "쇼핑 (Shopping)", "관광 (Activities)", "기타 (Others)"])
            item = st.text_input("상세 항목 (Item Description)")
            amount_origin = st.number_input(f"금액 ({currency})", min_value=0.0, step=1.0 if currency=="JPY" else 0.01, format="%.2f")
            manual_rate = st.number_input("환율 조정 (Exchange Rate)", value=float(current_rate), min_value=0.0, step=0.1, format="%.2f")
            
            submit = st.form_submit_button("추가하기 (Add Expense)")
            
            if submit:
                final_krw = amount_origin * manual_rate
                new_data = pd.DataFrame({
                    "Date": [pd.to_datetime(date)],
                    "Category": [category],
                    "Item": [item],
                    "Amount": [final_krw],
                    "Currency": [currency],
                    "Original Amount": [amount_origin],
                    "Exchange Rate": [manual_rate]
                })
                st.session_state.df_expenses = pd.concat([st.session_state.df_expenses, new_data], ignore_index=True)
                save_data(st.session_state.df_expenses, trip_id)
                st.success(f"✅ 추가 완료: {item}")
                st.rerun()

    with row1_col2:
        st.subheader("📊 카테고리별 지출")
        if not st.session_state.df_expenses.empty:
            fig = px.pie(st.session_state.df_expenses, values='Amount', names='Category', hole=0.4)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.info("데이터가 없습니다.")

    st.markdown("---")
    
    # 하단: 상세 내역 및 일별 추이
    row2_col1, row2_col2 = st.columns([1, 1])

    with row2_col1:
        st.subheader("📋 최근 지출 내역")
        if not st.session_state.df_expenses.empty:
            display_df = st.session_state.df_expenses.copy()
            display_df = display_df.reset_index()
            display_df = display_df.rename(columns={"index": "Original_Index"})
            display_df['Date'] = display_df['Date'].dt.date
            display_df = display_df.sort_values(by="Date", ascending=False)
            
            display_cols = ["Original_Index", "Date", "Category", "Item", "Original Amount", "Currency", "Amount", "Exchange Rate"]
            
            column_config = {
                "Original_Index": None,
                "Date": "날짜",
                "Category": "카테고리",
                "Item": "항목",
                "Original Amount": st.column_config.NumberColumn("현지 금액", format="%.2f"),
                "Currency": "통화",
                "Amount": st.column_config.NumberColumn("원화(KRW)", format="%d"),
                "Exchange Rate": st.column_config.NumberColumn("환율", format="%.2f")
            }

            st.info("🗑️ 지출 내역을 삭제하려면 체크박스를 선택하세요.")
            
            display_df_with_selections = display_df.copy()
            display_df_with_selections.insert(0, "Select", False)

            edited_df = st.data_editor(
                display_df_with_selections,
                column_config={
                    "Select": st.column_config.CheckboxColumn("선택"),
                    **column_config
                },
                hide_index=True,
                use_container_width=True,
                disabled=display_cols
            )
            
            if st.button("🗑️ 선택된 항목 삭제 (Delete Selected)", type="secondary"):
                selected_indices = edited_df[edited_df["Select"]]["Original_Index"].tolist()
                
                if selected_indices:
                    st.session_state.df_expenses = st.session_state.df_expenses.drop(selected_indices).reset_index(drop=True)
                    save_data(st.session_state.df_expenses, trip_id)
                    st.success(f"✅ {len(selected_indices)}개 항목 삭제됨")
                    st.rerun()
        else:
            st.text("지출 내역이 없습니다.")

    with row2_col2:
        st.subheader("📈 일별 지출 추이")
        if not st.session_state.df_expenses.empty:
            daily_df = st.session_state.df_expenses.copy()
            daily_df['Date'] = daily_df['Date'].dt.date
            daily_spend = daily_df.groupby('Date')['Amount'].sum().reset_index()
            
            fig_line = px.bar(daily_spend, x='Date', y='Amount', title='Day by Day Spending (KRW)', text_auto='.2s')
            st.plotly_chart(fig_line, use_container_width=True)
        else:
            st.text("차트 데이터가 없습니다.")
